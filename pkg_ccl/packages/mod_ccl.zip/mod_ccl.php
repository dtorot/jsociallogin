<?php

/**
 * @version     CVS: 1.0.0
 * @package     com_ccl
 * @subpackage  mod_ccl
 * @author      Component Creator <info@component-creator.com>
 * @copyright   2016 Component Creator
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;

require JModuleHelper::getLayoutPath('mod_ccl');
