<?php defined('_JEXEC') or die; ?>
<h1>Welcome to the Example Component</h1>
<p>This is a basic front-end component for Joomla 5.x.</p>
